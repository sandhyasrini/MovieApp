import { Component } from '@angular/core';

import {Directive } from '@angular/core'
import {HTTPTestComponent} from './http-test.component'

@Component({
  selector: 'app-root',
  template:    `<h1>{{title}}</h1>
    <nav>
     
      <a routerLink="/movie" routerLinkActive="active">Home</a>
       <a routerLink="/favorites" routerLinkActive="active">Favorites</a>
    </nav>
    <router-outlet></router-outlet>
  `,
  styleUrls: ['./app.component.css'],
  
})
export class AppComponent {
  title = 'Movie App!';
}
