export class genre{
    id:number;
    name:string;
}

