export class movieDetails{
    title:string;
    image:string;
    popularity:string;
    language:string;
    overview:string;
    genre:any
    constructor(title: string, image: string, popularity: string, language: string, overview: string,genre:any){}
} 


